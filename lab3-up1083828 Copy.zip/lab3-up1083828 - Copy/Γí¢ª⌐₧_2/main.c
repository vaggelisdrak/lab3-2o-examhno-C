#include <stdio.h>
#include <string.h>
#define W 5

void copymatrix(char words[W][9 + 1], char newwords[W][9 + 1],int k);
void loadmatrix(char newwords[W][9 + 1],int k);

int main () {
    char words[W][9 + 1] ;
    char newwords[W][9 + 1];
    char test[9 + 1];
    char endword[9 +1] = "end";
    int i,j=0;
    while (scanf("%s", test), strcmp(test,endword)) {
        if (i==5){
            break;
        }
        strcpy(words[i++], test);
        printf("%s\n", test);
        j++;
    }
    printf("\n");
    for (i=0; i<j; i++) {
        printf("%d %s\n", i, words[i]);
    }

    printf("\n");
    copymatrix(words,newwords,j);
    loadmatrix(newwords,j);

    return 0;

}

void copymatrix(char words[W][9 + 1],char newwords[W][9 + 1],int k)
{
    int i,j;
    for(i = 0; i < k; i++){
        strcpy(newwords[i], words[i]);
        strrev(newwords[i]);
    }

}

void loadmatrix(char newwords[W][9 + 1], int k)
{
    int j;
    for(j=0; j<k; j++){
        printf("%d %s\n", j, newwords[j]);
    }
}

