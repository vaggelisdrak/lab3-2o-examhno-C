#include <stdio.h>
#include <string.h>
#define W 5

void copymatrix(char words[W][9 + 1], char newwords[W][9 + 1],int k,int r);
void loadmatrix(char newwords[W][9 + 1],int k);
void caps(char newwords[W][9 + 1],int k);
void insert_word(char str[9+1], char newwords[W][9 + 1],int k);

int main () {
    char words[W][9 + 1] ;
    char newwords[W][9 + 1];
    char test[9 + 1];
    char endword[9 +1] = "end";
    char str[9+1];
    int i,j=0;
    while (scanf("%s", test), strcmp(test,endword)) {
        if (i==5){
            break;
        }
        strcpy(words[i++], test);
        printf("%s\n", test);
        j++;
    }
    printf("\n");
    for (i=0; i<j; i++) {
        printf("%d %s\n", i, words[i]);
    }

    printf("\ncopy:\n");
    copymatrix(words,newwords,j,1);
    loadmatrix(newwords,j);

    printf("\ncaps:\n");
    caps(newwords,j);
    loadmatrix(newwords,j);

    do{
        printf("\ngrapse mia symboloseira me max 9 xarakthres: ");
        scanf("%s",str);
    }while(strlen(str)>9);

    insert_word(str,newwords,j);
    loadmatrix(newwords,j);

    return 0;

}

void copymatrix(char words[W][9 + 1],char newwords[W][9 + 1],int k, int r)
{
    int i;
    for(i = 0; i < k; i++) {
        strcpy(newwords[i], words[i]);
        if(r==1){
            strrev(newwords[i]);
        }
    }
}

void loadmatrix(char newwords[W][9 + 1],int k)
{
    int j;
    for(j=0; j<k; j++){
        printf("%d %s\n", j, newwords[j]);
    }
}

void caps(char newwords[W][9 + 1], int k)
{
    int j,i;
    for(j=0; j<k; j++){
        for(i=0;newwords[j][i]!=0;i++){
            if (newwords[j][i]>='a' && newwords[j][i]<='z'){/*an a ascii xarakthras einai mikro gramma*/
                newwords[j][i]=newwords[j][i]-32;/*kanton kefalaio*/
            }
        }
    }
}

void insert_word(char str[9+1],char newwords[W][9 + 1],int k)
{
    char wordsreplica[W][9 + 1];
    copymatrix(newwords,wordsreplica,k,0);

    int i;
    for(i = 1; i < k; i++) {
        strcpy(newwords[i], wordsreplica[i-1]);/*kano copy stin thesi i thn i-1 apo ton omoio pinaka*/
    }
    strcpy(newwords[0], str);
}
