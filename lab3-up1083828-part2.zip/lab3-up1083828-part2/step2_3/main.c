#include <stdio.h>
#include <string.h>
#define L 20
#define W 50000

int epiloges(void);
void choose(char words[W][L], char lex[W][L],int w);
int eisagogi_keim(char words[W][L]);
int eisagogi_lex(char lex[W][L]);
void diorth_keim(void);
void apoth_keim(char words[W][L],int w);
void stats_keim(char words[W][L],int w);
void histogram(char words[W][L],int w);

int main ( ) {
    int w=0;
    char words[W][L];
    char lex[W][L];
    choose(words,lex,w);
    return 0;
}

int epiloges(void){
    printf("1-Eisagogh keimenou\n");
    printf("2-Eisagogh lexilogiou\n");
    printf("3-Leitourgia diorthosis keimenou\n");
    printf("4-Apothikeush keimenou\n");
    printf("5-Ypologismos statistikon tou keimenou\n");
    printf("6-Exodos\n");

    int i;
    scanf("%d",&i);
    return i;
}

void choose(char words[W][L], char lex[W][L],int w){
    int i=0;
    while(i!=6){
        i=epiloges();
        if(i==1){
            w=eisagogi_keim(words);
        }
        else if(i==2){
            eisagogi_lex(lex);
        }
        else if(i==3){
            diorth_keim();
        }
        else if(i==4){
            apoth_keim(words,w);
        }
        else if(i==5){
            stats_keim(words,w);
        }
        else{
            if(i!=6){
                printf("den yparxei ayth h epilogh!\n\n");
            }
        }
    }
}

int eisagogi_keim(char words[W][L]){
    char file[L];
    int n,i;
    n=0;
    i=0;
	printf("\nGive name of file: ");
	scanf("%15s", file);

    FILE *f;
    f = fopen(file, "r");
    if (f == NULL)
        printf("Unable to open this file\n");
    else {
		char word[L];
		while(fgets(word, sizeof(word), f) != NULL) {
            char *p;
            p = strtok (word," ,:/-'`*.!;?\n\t");
            while (p!= NULL)
            {
                printf ("%s\n",p);
                strcpy(words[i],p);
                n++;
                i++;
                p = strtok (NULL, " ,:/-'`*.!;?\n\t");
            }
		}
    }

    fclose(f);
    return n;
}

int eisagogi_lex(char lex[W][L]){
    char file[L];
    int n,i;
    n=0;
    i=0;
	printf("\nGive name of file: ");
	scanf("%15s", file);

    FILE *f;
    f = fopen(file, "r");
    if (f == NULL)
        printf("Unable to open this file\n");
    else {
		char word[L];
		while(fgets(word, sizeof(word), f) != NULL) {
            char *p;
            p = strtok (word," ,:/-'`*.!;?\n\t");
            while (p!= NULL)
            {
                printf ("%s\n",p);
                strcpy(lex[i],p);
                n++;
                i++;
                p = strtok (NULL, " ,:/-'`*.!;?\n\t");
            }
		}
    }

    fclose(f);
    return n;
}

void diorth_keim(void){
    printf("diorth_keim\n\n");
}

void apoth_keim(char words[W][L],int w){
    printf("\n Save\n");
	char file[L];

	printf("-Give name of file: ");
	scanf("%s", file);

	FILE *f = fopen(file, "w");
	int i;
	for(i=0;i<=w;i++){
        fprintf(f, "%s\n",words[i]);
	}
	fclose(f);
}

void stats_keim(char words[W][L],int w){
    int words_num=0;
    int chars_num=0;
    int duplicates=0;
    int i,j;

    for(i=0;i<w;i++){
        words_num++;
    }

    for(i=0;i<w;i++){
        chars_num += strlen(words[i]);
    }

    for(i=0; i<w; i++)
    {
        for(j=i+1; j<w; j++)
        {
            if(strcmp(words[i],words[j])==0)
            {
                duplicates++;
                break;
            }
        }
    }

    printf("to keimeno periexei %d lexeis kai %d xarakthres\n",words_num,chars_num);
    printf("to keimeno periexei %d diaforetikes lexeis\n\n",w-duplicates);
    histogram(words,w);

    FILE *f = fopen("statistics.txt", "a");
	fprintf(f, "Words: %d\nDifferent words: %d\nChars: %d\n", words_num, w-duplicates, chars_num);
	fclose(f);
}

void histogram(char words[W][L],int w){
    int chars_num[L],z;
    int i;

    for(i=0;i<L;i++){
        chars_num[i]=0;
    }

    for(i=0;i<w;i++){
        z = strlen(words[i]);
        chars_num[z]++;
    }

    FILE *f = fopen("statistics.txt", "w");
    for(i = 1; i < L; i++){
        printf("%d lexeis periexoun %d charakthres\n",chars_num[i],i);
        fprintf(f,"%d lexeis periexoun %d charakthres\n",chars_num[i],i);
    }
    printf("\n");
    fclose(f);
}

