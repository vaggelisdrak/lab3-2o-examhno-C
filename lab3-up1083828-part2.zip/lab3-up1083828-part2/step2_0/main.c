#include <stdio.h>
#include <string.h>

int epiloges(void);
void choose(void);
void eisagogi_keim(void);
void eisagogi_lex(void);
void diorth_keim(void);
void apoth_keim(void);
void stats_keim(void);

int main ( ) {
    choose();
    return 0;
}

int epiloges(void){
    printf("1-Eisagogh keimenou\n");
    printf("2-Eisagogh lexilogiou\n");
    printf("3-Leitourgia diorthosis keimenou\n");
    printf("4-Apothikeush keimenou\n");
    printf("5-Ypologismos statistikon tou keimenou\n");
    printf("6-Exodos\n");

    int i;
    scanf("%d",&i);
    return i;
}

void choose(void){
    int i;
    while(i!=6){
        i=epiloges();
        if(i==1){
            eisagogi_keim();
        }
        else if(i==2){
            eisagogi_lex();
        }
        else if(i==3){
            diorth_keim();
        }
        else if(i==4){
            apoth_keim();
        }
        else if(i==5){
            stats_keim();
        }
        else{
            if(i!=6){
                printf("den yparxei ayth h epilogh!\n\n");
            }
        }
    }
    return 0;
}

void eisagogi_keim(void){
    printf("eisagogi_keim\n\n");
}

void eisagogi_lex(void){
    printf("eisagogi_lex\n\n");
}

void diorth_keim(void){
    printf("diorth_keim\n\n");
}

void apoth_keim(void){
    printf("apoth_keim\n\n");
}

void stats_keim(void){
    printf("stats_keim\n\n");
}
