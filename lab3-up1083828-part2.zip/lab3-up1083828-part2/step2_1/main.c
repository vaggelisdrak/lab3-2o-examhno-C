#include <stdio.h>
#include <string.h>
#define W 5
#define L 20

int epiloges(void);
void choose(char words[W][L], char lex[L],int w);
int eisagogi_keim(char words[W][L]);
void eisagogi_lex(char lex[L]);
void diorth_keim(void);
void apoth_keim(void);
void stats_keim(char words[W][L],int w);
void histogram(char words[W][L],int w);

int main ( ) {
    char words[W][L];
    char lex[L];
    int w=0;
    choose(words,lex,w);
    return 0;
}

int epiloges(void){
    printf("1-Eisagogh keimenou\n");
    printf("2-Eisagogh lexilogiou\n");
    printf("3-Leitourgia diorthosis keimenou\n");
    printf("4-Apothikeush keimenou\n");
    printf("5-Ypologismos statistikon tou keimenou\n");
    printf("6-Exodos\n");

    int i;
    scanf("%d",&i);
    return i;
}

void choose(char words[W][L], char lex[L],int w){
    int i=0;
    while(i!=6){
        i=epiloges();
        if(i==1){
            w=eisagogi_keim(words);
        }
        else if(i==2){
            eisagogi_lex(lex);
        }
        else if(i==3){
            diorth_keim();
        }
        else if(i==4){
            apoth_keim();
        }
        else if(i==5){
            stats_keim(words,w);
        }
        else{
            if(i!=6){
                printf("den yparxei ayth h epilogh!\n\n");
            }
        }
    }
}

int eisagogi_keim(char words[W][L]){
    int i,n;
    n=0;
    printf("eisagogi keimenou:\n");
    for(i=0;i<W;i++){
        scanf("%15s",words[i]);
        if(strcmp(words[i],"*T*E*L*O*S*")==0){
            break;
        }
        n=i;
    }
    printf("\nto keimeno sas einai:\n");
    for(i=0;i<=n;i++){
        char *p;
        p = strtok (words[i],",:/-'`*");
        while (p!= NULL)
        {
            printf ("%s\n",p);
            p = strtok (NULL, ",:/-'`*");
        }
        //printf("%s\n",words[i]);
    }
    return n;

}
void eisagogi_lex(char lex[L]){
    printf("eisagogi lexilogiou:\n");
    scanf("%15s",lex);
    printf("\nh lexh poy prosthesate einai:\n");
    printf("%s\n",lex);
}

void diorth_keim(void){
    printf("diorth_keim\n\n");
}

void apoth_keim(void){
    printf("apoth_keim\n\n");
}

void stats_keim(char words[W][L],int w){
    int words_num=0;
    int chars_num=0;
    int duplicates=0;
    int i,j;

    for(i=0;i<=w;i++){
        words_num++;
    }

    for(i=0;i<=w;i++){
        chars_num += strlen(words[i]);
    }

    for(i=0; i<=w; i++)
    {
        for(j=i+1; j<=w; j++)
        {
            if(strcmp(words[i],words[j])==0)
            {
                duplicates++;
                break;
            }
        }
    }

    printf("to keimeno periexei %d lexeis kai %d xarakthres\n",words_num,chars_num);
    printf("to keimeno periexei %d diaforetikes lexeis\n\n",w-duplicates+1);
    histogram(words,w);
}

void histogram(char words[W][L],int w){
    int chars_num[L],z;
    int i;

    for(i=0;i<L;i++){
        chars_num[i]=0;
    }

    for(i=0;i<=w;i++){
        z = strlen(words[i]);
        chars_num[z]++;
    }

    for(i = 1; i < L; i++){
        printf("%d lexeis periexoun %d charakthres\n",chars_num[i],i);
    }
    printf("\n");
}

