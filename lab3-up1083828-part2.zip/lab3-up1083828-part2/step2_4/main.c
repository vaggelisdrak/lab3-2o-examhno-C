#include <stdio.h>
#include <string.h>
#define L 20
#define W 50000

int epiloges(void);
void choose(char words[W][L], char lex[W][L],int w);
int eisagogi_keim(char words[W][L]);
int eisagogi_lex(char lex[W][L]);
void diorth_keim(char words[W][L],char lex[W][L],int w);
void apoth_keim(char words[W][L],int w);
void stats_keim(char words[W][L],int w);
void histogram(char words[W][L],int w);
void add_word(char lexh[W][L]);
void replace_word(char words[W][L],char word[W][L],char lexh[W][L],int w);

int main ( ) {
    int w=0;
    char words[W][L];
    char lex[W][L];
    choose(words,lex,w);
    return 0;
}

int epiloges(void){
    printf("1-Eisagogh keimenou\n");
    printf("2-Eisagogh lexilogiou\n");
    printf("3-Leitourgia diorthosis keimenou\n");
    printf("4-Apothikeush keimenou\n");
    printf("5-Ypologismos statistikon tou keimenou\n");
    printf("6-Exodos\n");

    int i;
    scanf("%d",&i);
    return i;
}

void choose(char words[W][L], char lex[W][L],int w){
    int i=0;
    while(i!=6){
        i=epiloges();
        if(i==1){
            w=eisagogi_keim(words);
        }
        else if(i==2){
            eisagogi_lex(lex);
        }
        else if(i==3){
            diorth_keim(words,lex,w);
        }
        else if(i==4){
            apoth_keim(words,w);
        }
        else if(i==5){
            stats_keim(words,w);
        }
        else{
            if(i!=6){
                printf("den yparxei ayth h epilogh!\n\n");
            }
        }
    }
}

int eisagogi_keim(char words[W][L]){
    char file[L];
    int n,i;
    n=0;
    i=0;
	printf("\nGive name of file: ");
	scanf("%s", file);

    FILE *f;
    f = fopen(file, "r");
    if (f == NULL)
        printf("Unable to open this file\n");
    else {
		char word[L];
		while(fgets(word, sizeof(word), f) != NULL) {
            char *p;
            p = strtok (word," ,:/-'`*.!;?\n\t");
            while (p!= NULL)
            {
                printf ("%s\n",p);
                strcpy(words[i],p);
                n++;
                i++;
                p = strtok (NULL, " ,:/-'`*.!;?\n\t");
            }
		}
    }

    fclose(f);
    return n;
}

int eisagogi_lex(char lex[W][L]){
    int n,i;
    n=0;
    i=0;

    FILE *f;
    f = fopen("lexilogio.txt", "r");
    if (f == NULL)
        printf("Unable to open this file\n");
    else {
		char word[L];
		while(fgets(word, sizeof(word), f) != NULL) {
            char *p;
            p = strtok (word," ,:/-'`*.!;?\n\t");
            while (p!= NULL)
            {
                printf ("%s\n",p);
                strcpy(lex[i],p);
                n++;
                i++;
                p = strtok (NULL, " ,:/-'`*.!;?\n\t");
            }
		}
    }

    fclose(f);
    return n;
}

void diorth_keim(char words[W][L],char lex[W][L],int w){
    printf("\nCorrection\n");
    int n;
    n=eisagogi_lex(lex);
    int i,j;
    for(i=0;i<w;i++){
        for(j=0;j<=n;j++){
            //printf("%s,%s\n\n",words[i],lex[j]);
            if(strcmp(words[i],lex[j])==0){
                printf("\n--->h lexh %s tou keimenou yparxei sto lexilogio\n\n",words[i]);
                break;
            }
            else if (strcmp(words[i],lex[j])!=0 && j!=n){
                continue;
            }
            else{
                if(j==n){
                    printf("\n--->h lexh %s tou keimenou DEN yparxei sto lexilogio\n\n",words[i]);
                    printf("Epelexe mia apo tis parakato epiloges\n\n");
                    printf("1)antikatastash ths lexhs ayths me mia allh nea sto keimeno\n");
                    printf("2)prosthiki ths lexhs ayths sto lexilogio\n");
                    printf("3)kamia energeia sxetikh me aythn thn lexh kai synexish ths diadikasias elexou gia to ypoloipo keimeno\n");
                    printf("4)egkataleipsh ths leitourgias diorthosis\n");
                    int choice;
                    do {
                        printf("epilogh: ");
                        scanf("%d", &choice);
                        if(choice == 1) {
                            printf("dose nea lexh: ");
                            char new_word[L];
                            scanf("%s", new_word);

                            int k;
                            for(k=0;k<=n;k++){
                                if(strcmp(new_word,lex[k])==0){
                                    //printf("yparxei hdh ayth h lexh sto lexilogio\n");
                                    replace_word(words,words[i],new_word,w);
                                    break;
                                }
                                else if (strcmp(new_word,lex[k])!=0 && j!=n){
                                    continue;
                                }
                                else{
                                    replace_word(words,words[i],new_word,w);
                                    printf("->oloklhrothike h antikatastash ths lexhs\n");
                                    printf("--->DEN yparxei ayth h lexh sto lexilogio\n");
                                    printf("an thelete na thn prosthesete pathste to 3 ,diaforetika pathste opoiondhpote arithmo:");
                                    int answer;
                                    scanf("%d",&answer);
                                    if(answer==3){
                                        add_word(new_word);
                                        printf("h lexh prostethike sto lexilogio\n");
                                        break;
                                    }
                                    else{
                                        printf("h lexh den prostethike sto lexilogio\n");
                                        break;
                                    }
                                }
                            }
                        }
                        else if(choice == 2){
                            add_word(words[i]);
                            printf("h lexh prostethike sto lexilogio me epityxia!\n");
                            break;
                        }
                        else if(choice == 3){
                            continue;
                        }
                        else if(choice == 4){
                            return;
                        }
                        else{
                            printf("den yparxei ayth h epilogh");
                        }
                    } while (choice > 4 || choice < 1);
                }
            }
        }
    }
}



void add_word(char lexh[W][L]){
    FILE *f;
    f = fopen("lexilogio.txt", "a");
    fprintf(f,"%s\n",lexh);
    fclose(f);
}

void replace_word(char words[W][L],char word[W][L],char lexh[W][L],int w){
    char file[L];
    int i;
	printf("\nGive name of file to change the word: ");
	scanf("%s", file);

    FILE *f;
    f = fopen(file, "w");
    if (f == NULL)
        printf("Unable to open this file\n");
    else {
        for(i=0;i<w;i++){
            if(strcmp(words[i],word)==0){
                strcpy(words[i],lexh);
            }
            printf("%s\n",words[i]);
            fprintf(f,"%s",words[i]);
        }

    }
    fclose(f);
}

void apoth_keim(char words[W][L],int w){
    printf("\n Save\n");
	char file[L];

	printf("-Give name of file: ");
	scanf("%s", file);

	FILE *f = fopen(file, "w");
	int i;
	for(i=0;i<=w;i++){
        fprintf(f, "%s\n",words[i]);
	}
	fclose(f);
}

void stats_keim(char words[W][L],int w){
    int words_num=0;
    int chars_num=0;
    int duplicates=0;
    int i,j;

    for(i=0;i<w;i++){
        words_num++;
    }

    for(i=0;i<w;i++){
        chars_num += strlen(words[i]);
    }

    for(i=0; i<w; i++)
    {
        for(j=i+1; j<w; j++)
        {
            if(strcmp(words[i],words[j])==0)
            {
                duplicates++;
                break;
            }
        }
    }

    printf("to keimeno periexei %d lexeis kai %d xarakthres\n",words_num,chars_num);
    printf("to keimeno periexei %d diaforetikes lexeis\n\n",w-duplicates);
    histogram(words,w);

    FILE *f = fopen("statistics.txt", "a");
	fprintf(f, "Words: %d\nDifferent words: %d\nChars: %d\n", words_num, w-duplicates, chars_num);
	fclose(f);
}

void histogram(char words[W][L],int w){
    int chars_num[L],z;
    int i;

    for(i=0;i<L;i++){
        chars_num[i]=0;
    }

    for(i=0;i<w;i++){
        z = strlen(words[i]);
        chars_num[z]++;
    }

    FILE *f = fopen("statistics.txt", "w");
    for(i = 1; i < L; i++){
        printf("%d lexeis periexoun %d charakthres\n",chars_num[i],i);
        fprintf(f,"%d lexeis periexoun %d charakthres\n",chars_num[i],i);
    }
    printf("\n");
    fclose(f);
}

